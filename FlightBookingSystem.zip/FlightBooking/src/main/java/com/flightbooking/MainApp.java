package com.flightbooking;

import com.flightbooking.util.DatabaseManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Punto di ingresso principale dell'applicazione Sistema Prenotazione Voli.
 * Estende Application di JavaFX e gestisce il ciclo di vita dell'app.
 */
public class MainApp extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;

        // Inizializza il database SQLite
        DatabaseManager.getInstance().initializeDatabase();

        // Carica la schermata di Login
        FXMLLoader loader = new FXMLLoader(
            getClass().getResource("/com/flightbooking/fxml/LoginView.fxml")
        );
        Scene scene = new Scene(loader.load(), 1100, 700);
        scene.getStylesheets().add(
            getClass().getResource("/com/flightbooking/css/style.css").toExternalForm()
        );

        stage.setTitle("✈ SkyBook — Sistema Prenotazione Voli");
        stage.setScene(scene);
        stage.setMinWidth(1000);
        stage.setMinHeight(650);
        stage.centerOnScreen();
        stage.show();
    }

    /**
     * Naviga verso una nuova vista FXML.
     * @param fxmlPath percorso del file FXML
     * @param title    titolo della finestra
     */
    public static void navigateTo(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(
                MainApp.class.getResource("/com/flightbooking/fxml/" + fxmlPath)
            );
            Scene scene = new Scene(loader.load(), 1100, 700);
            scene.getStylesheets().add(
                MainApp.class.getResource("/com/flightbooking/css/style.css").toExternalForm()
            );
            primaryStage.setTitle("✈ SkyBook — " + title);
            primaryStage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
