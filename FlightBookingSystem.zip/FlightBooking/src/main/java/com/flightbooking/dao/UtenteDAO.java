package com.flightbooking.dao;

import com.flightbooking.model.Utente;
import com.flightbooking.util.DatabaseManager;
import com.flightbooking.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * DAO (Data Access Object) per la gestione degli utenti nel database.
 * Implementa le operazioni CRUD complete.
 */
public class UtenteDAO {

    private final DatabaseManager db = DatabaseManager.getInstance();

    /**
     * Autentica un utente tramite email e password.
     */
    public Optional<Utente> login(String email, String password) {
        String sql = "SELECT * FROM utenti WHERE email = ? AND password_hash = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, PasswordUtil.hash(password));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(mapUtente(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    /**
     * Registra un nuovo utente nel sistema.
     * @return true se la registrazione va a buon fine
     */
    public boolean registra(Utente utente) {
        String sql = """
            INSERT INTO utenti (nome, cognome, email, password_hash, telefono,
                data_nascita, codice_fiscale, ruolo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setString(1, utente.getNome());
            ps.setString(2, utente.getCognome());
            ps.setString(3, utente.getEmail());
            ps.setString(4, utente.getPasswordHash());
            ps.setString(5, utente.getTelefono());
            ps.setString(6, utente.getDataNascita());
            ps.setString(7, utente.getCodiceFiscale());
            ps.setString(8, utente.getRuolo() != null ? utente.getRuolo() : "UTENTE");
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Controlla se una email è già registrata.
     */
    public boolean emailEsiste(String email) {
        try (PreparedStatement ps = db.getConnection()
                .prepareStatement("SELECT COUNT(*) FROM utenti WHERE email = ?")) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Aggiorna i dati di un utente esistente.
     */
    public boolean aggiorna(Utente utente) {
        String sql = """
            UPDATE utenti SET nome=?, cognome=?, telefono=?,
                data_nascita=?, codice_fiscale=?
            WHERE id=?
        """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setString(1, utente.getNome());
            ps.setString(2, utente.getCognome());
            ps.setString(3, utente.getTelefono());
            ps.setString(4, utente.getDataNascita());
            ps.setString(5, utente.getCodiceFiscale());
            ps.setInt(6, utente.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Cambia la password di un utente.
     */
    public boolean cambiaPassword(int idUtente, String nuovaPassword) {
        try (PreparedStatement ps = db.getConnection()
                .prepareStatement("UPDATE utenti SET password_hash=? WHERE id=?")) {
            ps.setString(1, PasswordUtil.hash(nuovaPassword));
            ps.setInt(2, idUtente);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Restituisce tutti gli utenti (solo admin).
     */
    public List<Utente> getTutti() {
        List<Utente> lista = new ArrayList<>();
        try (ResultSet rs = db.getConnection().createStatement()
                .executeQuery("SELECT * FROM utenti ORDER BY cognome, nome")) {
            while (rs.next()) lista.add(mapUtente(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Utente mapUtente(ResultSet rs) throws SQLException {
        Utente u = new Utente();
        u.setId(rs.getInt("id"));
        u.setNome(rs.getString("nome"));
        u.setCognome(rs.getString("cognome"));
        u.setEmail(rs.getString("email"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setTelefono(rs.getString("telefono"));
        u.setDataNascita(rs.getString("data_nascita"));
        u.setCodiceFiscale(rs.getString("codice_fiscale"));
        u.setRuolo(rs.getString("ruolo"));
        return u;
    }
}
