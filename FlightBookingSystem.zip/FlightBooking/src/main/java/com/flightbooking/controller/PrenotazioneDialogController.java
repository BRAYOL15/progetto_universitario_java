package com.flightbooking.controller;

import com.flightbooking.dao.PrenotazioneDAO;
import com.flightbooking.model.Prenotazione;
import com.flightbooking.model.Volo;
import com.flightbooking.util.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller per il dialog di nuova prenotazione.
 * Permette di selezionare classe, optional e confermare il pagamento.
 */
public class PrenotazioneDialogController implements Initializable {

    @FXML private Label lblNumeroVolo;
    @FXML private Label lblRotta;
    @FXML private Label lblOrari;
    @FXML private Label lblDurata;
    @FXML private Label lblCompagnia;
    @FXML private Label lblGate;

    @FXML private ComboBox<String> cmbClasse;
    @FXML private Spinner<Integer> spinnerPasseggeri;
    @FXML private CheckBox chkBagaglio;
    @FXML private CheckBox chkAssicurazione;
    @FXML private TextArea txtNoteSpeciali;

    @FXML private Label lblPrezzoBase;
    @FXML private Label lblPrezzoOptional;
    @FXML private Label lblPrezzoTotale;
    @FXML private Label lblPostiDisponibili;

    private Volo volo;
    private Runnable onCompletata;
    private final PrenotazioneDAO prenotazioneDAO = new PrenotazioneDAO();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cmbClasse.getItems().addAll("Economy", "Business", "First Class");
        cmbClasse.setValue("Economy");

        SpinnerValueFactory<Integer> factory =
            new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 9, 1);
        spinnerPasseggeri.setValueFactory(factory);

        // Ricalcola prezzo ad ogni modifica
        cmbClasse.setOnAction(e -> aggiornaPrezzo());
        spinnerPasseggeri.valueProperty().addListener((o, v, n) -> aggiornaPrezzo());
        chkBagaglio.setOnAction(e -> aggiornaPrezzo());
        chkAssicurazione.setOnAction(e -> aggiornaPrezzo());
    }

    public void setVolo(Volo volo) {
        this.volo = volo;
        lblNumeroVolo.setText(volo.getNumeroVolo());
        lblRotta.setText(volo.getCodicePartenza() + "  →  " + volo.getCodiceArrivo());
        lblOrari.setText(volo.getDataPartenzaFormatted() + " → " + volo.getDataArrivoFormatted());
        lblDurata.setText("⏱ " + volo.getDurataVolo());
        lblCompagnia.setText("✈ " + volo.getCompagnia());
        lblGate.setText("Gate: " + (volo.getGateImbarco() != null ? volo.getGateImbarco() : "--"));
        lblPostiDisponibili.setText(volo.getPostiDisponibili() + " posti disponibili");
        aggiornaPrezzo();
    }

    public void setClasseSelezionata(String classe) {
        cmbClasse.setValue(classe);
        aggiornaPrezzo();
    }

    public void setNumeroPasseggeri(int n) {
        spinnerPasseggeri.getValueFactory().setValue(n);
        aggiornaPrezzo();
    }

    public void setOnPrenotazioneCompletata(Runnable r) {
        this.onCompletata = r;
    }

    private void aggiornaPrezzo() {
        if (volo == null) return;
        String classe = cmbClasse.getValue();
        int nPass = spinnerPasseggeri.getValue();

        double prezzoBase = switch (classe) {
            case "Business"    -> volo.getPrezzoBusiness();
            case "First Class" -> volo.getPrezzoFirstClass();
            default            -> volo.getPrezzoEconomy();
        };

        double optional = 0;
        if (chkBagaglio.isSelected())      optional += 35.0 * nPass;
        if (chkAssicurazione.isSelected()) optional += 25.0 * nPass;

        double totale = prezzoBase * nPass + optional;

        lblPrezzoBase.setText(String.format("€ %.2f × %d = € %.2f",
            prezzoBase, nPass, prezzoBase * nPass));
        lblPrezzoOptional.setText(optional > 0 ?
            String.format("+ € %.2f (optional)", optional) : "");
        lblPrezzoTotale.setText(String.format("€ %.2f", totale));
    }

    @FXML
    private void handleConferma() {
        if (volo == null) return;

        int nPass = spinnerPasseggeri.getValue();
        if (nPass > volo.getPostiDisponibili()) {
            mostraErrore("Posti insufficienti. Disponibili: " + volo.getPostiDisponibili());
            return;
        }

        Prenotazione p = new Prenotazione();
        p.setVolo(volo);
        p.setUtente(SessionManager.getInstance().getUtenteCorrente());
        p.setClasseVolo(switch (cmbClasse.getValue()) {
            case "Business"    -> Prenotazione.ClasseVolo.BUSINESS;
            case "First Class" -> Prenotazione.ClasseVolo.FIRST_CLASS;
            default            -> Prenotazione.ClasseVolo.ECONOMY;
        });
        p.setNumeroPasseggeri(nPass);
        p.setBagaglioExtra(chkBagaglio.isSelected());
        p.setAssicurazione(chkAssicurazione.isSelected());
        p.setNoteSpeciali(txtNoteSpeciali.getText());
        p.setPrezzoTotale(p.calcolaPrezzo());
        p.setStato(Prenotazione.Stato.CONFERMATA);

        if (prenotazioneDAO.inserisci(p)) {
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("✅ Prenotazione Confermata!");
            a.setHeaderText("Prenotazione effettuata con successo");
            a.setContentText("Codice: " + p.getCodicePrenotazione() +
                "\nVolo: " + volo.getNumeroVolo() +
                "\nPrezzo: € " + String.format("%.2f", p.getPrezzoTotale()));
            a.showAndWait();
            if (onCompletata != null) onCompletata.run();
        } else {
            mostraErrore("Errore durante la prenotazione. Riprova.");
        }
    }

    @FXML
    private void handleAnnulla() {
        cmbClasse.getScene().getWindow().hide();
    }

    private void mostraErrore(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Errore");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}
