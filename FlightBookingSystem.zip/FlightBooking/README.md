# ✈ SkyBook — Sistema di Prenotazione Voli
### Progetto Universitario — Java con JavaFX e SceneBuilder

---

## 📋 Panoramica del Progetto

**SkyBook** è un sistema completo per la prenotazione di voli aerei sviluppato in Java con interfaccia grafica JavaFX. Il progetto implementa tutti i principi fondamentali della programmazione orientata agli oggetti e dei pattern architetturali moderni.

---

## 🏗️ Architettura del Progetto

```
FlightBookingSystem/
├── pom.xml                                         ← Dipendenze Maven
└── src/main/
    ├── java/
    │   ├── module-info.java                        ← Modulo Java
    │   └── com/flightbooking/
    │       ├── MainApp.java                        ← Entry point
    │       ├── model/                              ← Entità di dominio
    │       │   ├── Utente.java
    │       │   ├── Volo.java
    │       │   └── Prenotazione.java
    │       ├── dao/                                ← Accesso al database
    │       │   ├── UtenteDAO.java
    │       │   ├── VoloDAO.java
    │       │   └── PrenotazioneDAO.java
    │       ├── controller/                         ← Controller JavaFX
    │       │   ├── LoginController.java
    │       │   ├── DashboardController.java
    │       │   ├── PrenotazioneDialogController.java
    │       │   ├── DettagliPrenotazioneController.java
    │       │   ├── AdminDashboardController.java
    │       │   └── FormVoloController.java
    │       └── util/                               ← Utilità trasversali
    │           ├── DatabaseManager.java
    │           ├── SessionManager.java
    │           └── PasswordUtil.java
    └── resources/com/flightbooking/
        ├── fxml/                                   ← Viste SceneBuilder
        │   ├── LoginView.fxml
        │   ├── Dashboard.fxml
        │   ├── PrenotazioneDialog.fxml
        │   ├── DettagliPrenotazione.fxml
        │   ├── AdminDashboard.fxml
        │   └── FormVolo.fxml
        └── css/
            └── style.css                           ← Stile globale
```

---

## 🎯 Pattern Architetturali Implementati

| Pattern | Dove | Descrizione |
|---|---|---|
| **MVC** | Tutta l'app | Model (model/), View (fxml/), Controller (controller/) |
| **DAO** | Layer dati | UtenteDAO, VoloDAO, PrenotazioneDAO per separare DB da logica |
| **Singleton** | DatabaseManager, SessionManager | Una sola istanza condivisa |
| **Observer** | JavaFX Properties | Binding reattivo tra UI e dati |
| **Factory Method** | FXMLLoader | Creazione dinamica delle viste |

---

## 🛠️ Tecnologie Utilizzate

| Tecnologia | Versione | Utilizzo |
|---|---|---|
| **Java** | 17+ | Linguaggio principale |
| **JavaFX** | 21.0.1 | Interfaccia grafica |
| **SceneBuilder** | 21+ | Progettazione FXML visuale |
| **SQLite** | 3.43 | Database embedded |
| **Maven** | 3.8+ | Gestione dipendenze e build |
| **SHA-256** | JDK built-in | Hash password (sicurezza) |

---

## ✨ Funzionalità Implementate

### 👤 Utente Standard
- **Login / Registrazione** con validazione campi e hash password SHA-256
- **Ricerca Voli** con filtri per partenza, arrivo e data (ricerca parziale LIKE)
- **Prenotazione** con scelta classe (Economy/Business/First Class), numero passeggeri, optional (bagaglio extra, assicurazione)
- **Riepilogo Prezzo** calcolato in tempo reale al cambio dei parametri
- **Storico Prenotazioni** con visualizzazione stato e dettagli completi
- **Cancellazione Prenotazione** con ripristino automatico posti disponibili
- **Boarding Pass** digitale con tutti i dettagli del volo

### 🔐 Amministratore
- **Dashboard Statistiche** (totale voli, prenotazioni, utenti, incasso)
- **Gestione Voli** completa (CRUD: creazione, modifica, eliminazione)
- **Gestione Prenotazioni** con cambio stato (conferma/cancella)
- **Gestione Utenti** con visualizzazione lista completa

---

## 🗄️ Schema Database (SQLite)

```sql
utenti(id, nome, cognome, email, password_hash, telefono,
       data_nascita, codice_fiscale, ruolo, data_registrazione)

voli(id, numero_volo, compagnia, aeroporto_partenza, codice_partenza,
     aeroporto_arrivo, codice_arrivo, data_ora_partenza, data_ora_arrivo,
     posti_totali, posti_disponibili, prezzo_economy, prezzo_business,
     prezzo_first_class, stato, gate_imbarco)

prenotazioni(id, codice_prenotazione, id_utente, id_volo, classe_volo,
             numero_passeggeri, prezzo_totale, stato, data_prenotazione,
             note_speciali, bagaglio_extra, assicurazione, numero_posto,
             FOREIGN KEY id_utente → utenti, FOREIGN KEY id_volo → voli)
```

---

## 🚀 Come Avviare il Progetto

### Prerequisiti
- Java JDK 17 o superiore
- Maven 3.8+
- IntelliJ IDEA o Eclipse con plugin JavaFX
- SceneBuilder 21+ (opzionale, per modificare i file FXML)

### Avvio con Maven
```bash
# Entra nella cartella del progetto
cd FlightBookingSystem

# Compila e avvia
mvn javafx:run
```

### Avvio da IntelliJ IDEA
1. File → Open → seleziona la cartella `FlightBookingSystem`
2. Attendi il download delle dipendenze Maven
3. Apri `MainApp.java` e clicca ▶ Run

---

## 🔑 Credenziali Demo

| Ruolo | Email | Password |
|---|---|---|
| **Admin** | admin@skybook.it | admin |
| **Utente** | mario.rossi@email.it | demo123 |

> Il database SQLite (`skybook.db`) viene creato automaticamente alla prima esecuzione nella cartella di lavoro, già popolato con 8 voli di esempio.

---

## 📐 Diagramma delle Classi (Relazioni principali)

```
MainApp
  ├── DatabaseManager (Singleton)
  ├── SessionManager (Singleton)
  └── FXMLLoader → Controllers
        ├── LoginController
        │     └── UtenteDAO → Utente
        ├── DashboardController
        │     ├── VoloDAO → Volo
        │     └── PrenotazioneDAO → Prenotazione
        │           ├── Utente (ha-un)
        │           └── Volo (ha-un)
        └── AdminDashboardController
              ├── VoloDAO
              ├── PrenotazioneDAO
              └── UtenteDAO
```

---

## 🎨 Decisioni di Design UI/UX

- **Palette colori**: Blu aviazione `#1a2f5e` + Accento azzurro `#00a8ff`
- **Layout a sidebar**: Navigazione laterale fissa, contenuto principale scorrevole
- **Feedback immediato**: Prezzi aggiornati in real-time, messaggi di errore inline
- **Boarding Pass**: Visualizzazione dettagli prenotazione in stile carta d'imbarco
- **Separazione Admin/User**: Sidebar diversa con badge "PANNELLO ADMIN"

---

## 🔒 Sicurezza Implementata

- Password hashate con **SHA-256** (mai in chiaro nel DB)
- Sessione gestita con **SessionManager** (no dati sensibili in memoria)
- **Foreign Keys** attive su SQLite (`PRAGMA foreign_keys = ON`)
- Validazione input lato client con regex e controlli semantici
- Controllo disponibilità posti **atomico** prima di ogni prenotazione

---

## 📚 Concetti OOP Dimostrati

1. **Incapsulamento** — tutti i campi dei Model sono privati con getter/setter
2. **Ereditarietà** — Controller implementano `Initializable` di JavaFX
3. **Polimorfismo** — `Stato` enum con metodi `getStatoLabel()` per ogni tipo
4. **Interfacce** — `Runnable` usato come callback per dialog asincroni
5. **Generics** — `Optional<T>`, `List<T>`, `ObservableList<T>` ovunque
6. **Lambda/Stream** — Java 8+ per calcoli (es. somma incasso totale)
7. **Switch Expression** — Java 14+ nei metodi di mapping enum → String
8. **Text Blocks** — Java 13+ nelle query SQL multilinea nei DAO

---

*Sviluppato come progetto universitario — Sistema Prenotazione Voli in Java/JavaFX*
